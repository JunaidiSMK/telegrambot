const settings = ctx => ctx.reply('settings');
module.exports = [ settings ];

