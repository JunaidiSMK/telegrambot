require('toml-require').install();
const config = require('../config.toml');
module.exports = config;

